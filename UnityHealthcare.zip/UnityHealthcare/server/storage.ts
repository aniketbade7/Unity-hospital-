import { users, type User, type InsertUser, 
         appointments, type Appointment, type InsertAppointment,
         contactMessages, type ContactMessage, type InsertContactMessage,
         testimonials, type Testimonial, type InsertTestimonial } from "@shared/schema";

// Interface definition for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Appointment operations
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  getAllAppointments(): Promise<Appointment[]>;
  
  // Contact Message operations
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getContactMessage(id: number): Promise<ContactMessage | undefined>;
  getAllContactMessages(): Promise<ContactMessage[]>;
  
  // Testimonial operations
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  getTestimonial(id: number): Promise<Testimonial | undefined>;
  getAllTestimonials(): Promise<Testimonial[]>;
  getPublishedTestimonials(): Promise<Testimonial[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private appointments: Map<number, Appointment>;
  private contactMessages: Map<number, ContactMessage>;
  private testimonialsList: Map<number, Testimonial>;
  private userCurrentId: number;
  private appointmentCurrentId: number;
  private messageCurrentId: number;
  private testimonialCurrentId: number;

  constructor() {
    this.users = new Map();
    this.appointments = new Map();
    this.contactMessages = new Map();
    this.testimonialsList = new Map();
    this.userCurrentId = 1;
    this.appointmentCurrentId = 1;
    this.messageCurrentId = 1;
    this.testimonialCurrentId = 1;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Appointment operations
  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentCurrentId++;
    const createdAt = new Date();
    const status = "pending";
    
    // Handle values that might be undefined but schema requires non-null
    const email = insertAppointment.email || '';
    const message = insertAppointment.message || '';
    
    const appointment: Appointment = { 
      ...insertAppointment,
      email,
      message,
      id, 
      createdAt, 
      status 
    };
    
    this.appointments.set(id, appointment);
    return appointment;
  }
  
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }
  
  async getAllAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values());
  }
  
  // Contact Message operations
  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.messageCurrentId++;
    const createdAt = new Date();
    const isRead = false;
    
    // Handle values that might be undefined but schema requires non-null
    const subject = insertMessage.subject || '';
    
    const message: ContactMessage = { 
      ...insertMessage,
      subject, 
      id, 
      createdAt, 
      isRead 
    };
    
    this.contactMessages.set(id, message);
    return message;
  }
  
  async getContactMessage(id: number): Promise<ContactMessage | undefined> {
    return this.contactMessages.get(id);
  }
  
  async getAllContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values());
  }
  
  // Testimonial operations
  async createTestimonial(insertTestimonial: InsertTestimonial): Promise<Testimonial> {
    const id = this.testimonialCurrentId++;
    const createdAt = new Date();
    const published = true;
    
    // Handle case where initials might be missing
    const initials = insertTestimonial.initials || '';
    
    const testimonial: Testimonial = { 
      ...insertTestimonial,
      initials,
      id, 
      createdAt, 
      published 
    };
    
    this.testimonialsList.set(id, testimonial);
    return testimonial;
  }
  
  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    return this.testimonialsList.get(id);
  }
  
  async getAllTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonialsList.values());
  }
  
  async getPublishedTestimonials(): Promise<Testimonial[]> {
    return Array.from(this.testimonialsList.values())
      .filter(testimonial => testimonial.published);
  }
}

export const storage = new MemStorage();
