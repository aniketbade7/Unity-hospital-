import React from 'react';
import { facilities } from '@/lib/data';

const FacilitiesSection: React.FC = () => {
  return (
    <section id="facilities" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">State-of-the-Art Facilities at Unity Hospital</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Experience healthcare in a modern and comfortable environment equipped with the latest medical technology.
          </p>
          <div className="w-20 h-1 bg-primary mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {facilities.map((facility, index) => (
            <div key={index} className="relative rounded-xl overflow-hidden group">
              <img 
                src={facility.image} 
                alt={facility.title} 
                className="w-full h-72 object-cover object-center group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                <h3 className="text-white font-heading font-bold text-xl mb-2">{facility.title}</h3>
                <p className="text-white/90 text-sm">{facility.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FacilitiesSection;
