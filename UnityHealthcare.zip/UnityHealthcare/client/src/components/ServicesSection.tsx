import React from 'react';
import { services } from '@/lib/data';

const ServicesSection: React.FC = () => {
  return (
    <section id="services" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Comprehensive Healthcare Services</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We offer a wide range of medical services to meet all your healthcare needs under one roof.
          </p>
          <div className="w-20 h-1 bg-primary mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition group">
              <div className="h-40 bg-tertiary group-hover:bg-primary transition-all overflow-hidden flex items-center justify-center">
                <i className={`${service.icon} text-white text-5xl`}></i>
              </div>
              <div className="p-6">
                <h3 className="font-heading font-bold text-xl mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <a href="#" className="text-primary font-semibold inline-flex items-center">
                  Learn More <i className="fas fa-arrow-right ml-2 group-hover:ml-3 transition-all"></i>
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* View All Services Button */}
        <div className="text-center mt-10">
          <button className="bg-tertiary hover:bg-tertiary/90 text-white font-bold px-8 py-3 rounded-md inline-flex items-center transition">
            View All Services <i className="fas fa-plus ml-2"></i>
          </button>
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
