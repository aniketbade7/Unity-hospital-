import React from 'react';

const GoogleMap: React.FC = () => {
  return (
    <div className="w-full h-full">
      <iframe 
        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59858.39753252852!2d74.41680642660766!3d19.870377514582164!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdc773fe8ce3ee1%3A0x3fe2da2ddac5c93a!2sPathardi%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1603879034316!5m2!1sen!2sin" 
        width="100%" 
        height="100%" 
        style={{ border: 0 }}
        allowFullScreen 
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        title="Unity Hospital Location"
        aria-label="Map showing location of Unity Hospital in Pathardi, Maharashtra"
      ></iframe>
    </div>
  );
};

export default GoogleMap;
