import React, { useState, useEffect } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useMediaQuery } from '@/hooks/use-mobile';

// Import logo using the direct path
import logoPath from '@assets/IMG_20250516_013909_506.jpg';

const navLinks = [
  { name: "Home", href: "#home" },
  { name: "About", href: "#about" },
  { name: "Services", href: "#services" },
  { name: "Doctors", href: "#doctors" },
  { name: "Facilities", href: "#facilities" },
  { name: "Contact", href: "#contact" }
];

const Header: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const isMobile = useMediaQuery("(max-width: 768px)");

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const href = e.currentTarget.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const targetId = href;
      const element = document.querySelector(targetId);

      if (element) {
        const offsetTop = element.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }

      // Close mobile menu if open
      if (mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    }
  };

  return (
    <header className={`sticky top-0 bg-white z-50 transition-shadow ${scrolled ? 'shadow-md' : ''}`}>
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo and Name */}
          <div className="flex items-center">
            <img src={logoPath} alt="Unity Hospital Logo" className="h-14 w-14 mr-3 rounded-full" />
            <div className="hidden md:block">
              <h1 className="text-xl font-heading font-bold">UNITY HOSPITAL</h1>
              <p className="text-sm text-gray-600">& ACCIDENT CARE</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-6 font-medium">
            {navLinks.map((link) => (
              <a 
                key={link.name}
                href={link.href}
                className="hover:text-primary transition"
                onClick={handleNavClick}
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* Book Appointment Button */}
          <a 
            href="#appointment" 
            className="hidden md:inline-block bg-primary hover:bg-primary/90 text-white font-semibold px-4 py-2 rounded-md transition"
            onClick={handleNavClick}
          >
            Book Appointment
          </a>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-dark focus:outline-none" 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle mobile menu"
          >
            <i className={`fas ${mobileMenuOpen ? 'fa-times' : 'fa-bars'} text-2xl`}></i>
          </button>
        </div>

        {/* Mobile Navigation */}
        <div className={`md:hidden ${mobileMenuOpen ? 'block' : 'hidden'} mt-4 pb-4`}>
          <nav className="flex flex-col space-y-3 font-medium">
            {navLinks.map((link) => (
              <a 
                key={link.name}
                href={link.href}
                className="py-2 px-4 hover:bg-gray-100 rounded-md"
                onClick={handleNavClick}
              >
                {link.name}
              </a>
            ))}
            <a 
              href="#appointment" 
              className="bg-primary text-white text-center font-semibold py-2 px-4 rounded-md"
              onClick={handleNavClick}
            >
              Book Appointment
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;
