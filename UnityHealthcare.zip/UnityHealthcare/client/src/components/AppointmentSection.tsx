import React from 'react';
import AppointmentForm from './AppointmentForm';

const AppointmentSection: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const href = e.currentTarget.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const targetId = href;
      const element = document.querySelector(targetId);

      if (element) {
        const offsetTop = element.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    }
  };
  
  return (
    <section id="appointment" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Book Your Appointment Easily</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Schedule a visit with our specialists. We'll get back to you with confirmation.
          </p>
          <div className="w-20 h-1 bg-primary mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Appointment Form */}
          <div className="bg-light p-8 rounded-xl shadow-md">
            <h3 className="text-2xl font-heading font-bold mb-6">Request an Appointment</h3>
            <AppointmentForm />
          </div>

          {/* Contact Information */}
          <div className="flex flex-col justify-between">
            <div>
              <h3 className="text-2xl font-heading font-bold mb-6">Other Ways to Reach Us</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-phone text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-lg">Phone</h4>
                    <p className="text-gray-600">Call us directly to speak with our staff</p>
                    <a href="tel:+918698097916" className="text-tertiary font-medium">+91 8698 097 916</a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fab fa-whatsapp text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-lg">WhatsApp</h4>
                    <p className="text-gray-600">Message us for quick responses</p>
                    <a href="https://wa.me/918698097916" className="text-tertiary font-medium">+91 8698 097 916</a>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-envelope text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-lg">Email</h4>
                    <p className="text-gray-600">Send us your queries anytime</p>
                    <a href="mailto:info@unityhospital.com" className="text-tertiary font-medium">info@unityhospital.com</a>
                  </div>
                </div>
              </div>
            </div>

            {/* Hospital Hours */}
            <div className="mt-10 bg-gray-50 p-6 rounded-xl">
              <h4 className="font-heading font-bold text-lg mb-4">Hospital Hours</h4>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">Monday - Friday:</span>
                  <span className="font-medium">8:00 AM - 9:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">Saturday:</span>
                  <span className="font-medium">8:00 AM - 7:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">Sunday:</span>
                  <span className="font-medium">9:00 AM - 5:00 PM</span>
                </li>
                <li className="flex justify-between mt-2 pt-2 border-t border-gray-200">
                  <span className="text-gray-600">Emergency Services:</span>
                  <span className="font-medium text-emergency">24/7</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppointmentSection;
