import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { testimonials as fallbackTestimonials } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { type Testimonial } from '@shared/schema';

const TestimonialsSection: React.FC = () => {
  const { data: testimonials, isLoading, error } = useQuery({
    queryKey: ['/api/testimonials'],
    queryFn: async () => {
      const response = await fetch('/api/testimonials');
      if (!response.ok) {
        throw new Error('Failed to fetch testimonials');
      }
      return response.json() as Promise<Testimonial[]>;
    },
  });

  // Show the fallback testimonials if we're loading or have an error
  const displayTestimonials = testimonials || fallbackTestimonials;

  return (
    <section id="testimonials" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">What Our Patients Say</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Hear from those who have experienced our care firsthand.
          </p>
          <div className="w-20 h-1 bg-primary mx-auto mt-4"></div>
        </div>

        {isLoading && (
          <div className="flex justify-center my-12">
            <div className="animate-pulse flex space-x-4">
              <div className="flex-1 space-y-6">
                <div className="h-4 bg-gray-300 rounded"></div>
                <div className="space-y-3">
                  <div className="h-4 bg-gray-300 rounded"></div>
                  <div className="h-4 bg-gray-300 rounded"></div>
                </div>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className="text-center text-red-500 mb-6">
            Unable to load testimonials. Please try again later.
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {displayTestimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md">
              <div className="flex items-center mb-4">
                <div className="text-yellow-400 flex">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <i key={i} className="fas fa-star"></i>
                  ))}
                  {testimonial.rating % 1 !== 0 && (
                    <i className="fas fa-star-half-alt"></i>
                  )}
                </div>
              </div>
              <p className="text-gray-600 mb-6">
                "{testimonial.text}"
              </p>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center mr-4">
                  <span className="text-primary font-bold">{testimonial.initials}</span>
                </div>
                <div>
                  <h4 className="font-heading font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Button 
            variant="outline" 
            className="border-primary text-primary hover:bg-primary hover:text-white"
            onClick={() => window.location.href = "#feedback"}
          >
            Share Your Experience
          </Button>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
