import React from 'react';
import logoPath from '@assets/IMG_20250516_013909_506.jpg';

const Footer: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const href = e.currentTarget.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const targetId = href;
      const element = document.querySelector(targetId);

      if (element) {
        const offsetTop = element.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    }
  };
  
  return (
    <footer className="bg-dark text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          {/* About Hospital */}
          <div>
            <div className="flex items-center mb-6">
              <img src={logoPath} alt="Unity Hospital Logo" className="h-12 w-12 mr-3 rounded-full" />
              <div>
                <h3 className="text-xl font-heading font-bold">UNITY HOSPITAL</h3>
                <p className="text-sm text-gray-400">& ACCIDENT CARE</p>
              </div>
            </div>
            <p className="text-gray-400 mb-6">
              Providing comprehensive healthcare services with a commitment to excellence and patient-centered care.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="https://www.instagram.com/unity.group_official?utm_source=qr&igsh=YzI4NTUwdWltM2g=" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition">
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-heading font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3">
              <li><a href="#home" className="text-gray-400 hover:text-white transition" onClick={handleNavClick}>Home</a></li>
              <li><a href="#about" className="text-gray-400 hover:text-white transition" onClick={handleNavClick}>About Us</a></li>
              <li><a href="#services" className="text-gray-400 hover:text-white transition" onClick={handleNavClick}>Our Services</a></li>
              <li><a href="#doctors" className="text-gray-400 hover:text-white transition" onClick={handleNavClick}>Our Doctors</a></li>
              <li><a href="#facilities" className="text-gray-400 hover:text-white transition" onClick={handleNavClick}>Facilities</a></li>
              <li><a href="#contact" className="text-gray-400 hover:text-white transition" onClick={handleNavClick}>Contact Us</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-xl font-heading font-bold mb-6">Our Services</h3>
            <ul className="space-y-3">
              <li><a href="#" className="text-gray-400 hover:text-white transition">General Medicine</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Surgery</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Obstetrics & Gynecology</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Pediatrics</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Orthopedics</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition">Cardiology</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-heading font-bold mb-6">Contact Information</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-primary"></i>
                <span className="text-gray-400">Unity Hospital I.C.U. & Accident Care Center, Amina Complex, Society Petrol Pump Near, Pathardi, Dist. Ahmednagar</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-phone mt-1 mr-3 text-primary"></i>
                <span className="text-gray-400">+91 8698 097 916 (Main & Emergency)</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-envelope mt-1 mr-3 text-primary"></i>
                <span className="text-gray-400">info@unityhospital.com</span>
              </li>
              <li className="flex items-start">
                <i className="fas fa-clock mt-1 mr-3 text-primary"></i>
                <div>
                  <span className="text-gray-400">Mon-Fri: 8AM - 9PM</span><br />
                  <span className="text-gray-400">Sat: 8AM - 7PM, Sun: 9AM - 5PM</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-gray-700 text-center">
          <p className="text-gray-400">&copy; {new Date().getFullYear()} Unity Hospital, Pathardi. All Rights Reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
