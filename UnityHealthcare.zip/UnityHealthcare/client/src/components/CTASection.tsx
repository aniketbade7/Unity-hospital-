import React from 'react';

const CTASection: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const href = e.currentTarget.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const targetId = href;
      const element = document.querySelector(targetId);

      if (element) {
        const offsetTop = element.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    }
  };
  
  return (
    <section className="py-14 bg-gradient-to-r from-tertiary to-primary text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl md:text-3xl font-heading font-bold mb-4">Your Health Is Our Priority</h2>
        <p className="text-lg opacity-90 mb-8 max-w-3xl mx-auto">
          Experience the difference of patient-centered care at Unity Hospital. Our team is ready to provide you with the highest quality healthcare services.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <a 
            href="#appointment" 
            className="bg-white text-primary hover:bg-gray-100 font-bold px-8 py-3 rounded-md transition"
            onClick={handleNavClick}
          >
            Book an Appointment
          </a>
          <a 
            href="#contact" 
            className="bg-transparent border-2 border-white hover:bg-white/10 text-white font-bold px-8 py-3 rounded-md transition"
            onClick={handleNavClick}
          >
            Contact Us
          </a>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
