import React from 'react';
import { doctors } from '@/lib/data';

const DoctorsSection: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const href = e.currentTarget.getAttribute('href');
    if (href && href.startsWith('#')) {
      e.preventDefault();
      const targetId = href;
      const element = document.querySelector(targetId);

      if (element) {
        const offsetTop = element.getBoundingClientRect().top + window.pageYOffset;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    }
  };
  
  return (
    <section id="doctors" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Meet Our Expert Medical Team</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Our highly qualified doctors are committed to providing exceptional healthcare services.
          </p>
          <div className="w-20 h-1 bg-primary mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {doctors.map((doctor, index) => (
            <div key={index} className="bg-light rounded-xl shadow-md overflow-hidden hover:shadow-lg transition group">
              <div className="bg-gradient-to-r from-[#0f84b5]/10 to-[#00a550]/10 p-6">
                <div className="flex items-center justify-center mb-4">
                  <div className="w-24 h-24 bg-white rounded-full shadow-md overflow-hidden flex items-center justify-center">
                    <img 
                      src={doctor.image} 
                      alt={`Medical symbol for ${doctor.specialty}`} 
                      className="w-20 h-20 object-cover"
                    />
                  </div>
                </div>
                <h3 className="font-heading font-bold text-xl mb-1 text-center">{doctor.name}</h3>
                <p className="text-primary font-medium mb-2 text-center">{doctor.specialty}</p>
              </div>
              <div className="p-6">
                <p className="text-gray-600 mb-4">{doctor.bio}</p>
                <div className="flex justify-between items-center">
                  <div className="flex space-x-2">
                    <a href="#" className="text-tertiary hover:text-tertiary/80 transition"><i className="fab fa-linkedin text-lg"></i></a>
                    <a href="#" className="text-tertiary hover:text-tertiary/80 transition"><i className="fas fa-envelope text-lg"></i></a>
                  </div>
                  <a 
                    href="#appointment" 
                    className="bg-primary hover:bg-primary/90 text-white font-semibold px-4 py-2 rounded-md transition text-sm"
                    onClick={handleNavClick}
                  >
                    Book Appointment
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* View All Doctors Button */}
        <div className="text-center mt-10">
          <button className="bg-tertiary hover:bg-tertiary/90 text-white font-bold px-8 py-3 rounded-md inline-flex items-center transition">
            View All Doctors <i className="fas fa-plus ml-2"></i>
          </button>
        </div>
      </div>
    </section>
  );
};

export default DoctorsSection;
