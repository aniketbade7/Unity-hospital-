import React from 'react';

const stats = [
  { value: "15+", label: "Specialist Doctors" },
  { value: "5000+", label: "Patients Treated" },
  { value: "500+", label: "Successful Surgeries" },
  { value: "24/7", label: "Emergency Service" }
];

const StatisticsSection: React.FC = () => {
  return (
    <section className="py-14 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {stats.map((stat, index) => (
            <div key={index}>
              <div className="text-4xl md:text-5xl font-bold mb-2">{stat.value}</div>
              <p className="text-white/80">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default StatisticsSection;
