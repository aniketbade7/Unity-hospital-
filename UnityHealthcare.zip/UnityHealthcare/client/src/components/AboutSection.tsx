import React from 'react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">About Unity Hospital</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
        </div>

        <div className="flex flex-col md:flex-row items-center gap-10">
          {/* About Content */}
          <div className="md:w-1/2">
            <p className="text-lg mb-6 leading-relaxed">
              Located in the heart of Pathardi, Unity Hospital is a multi-specialty healthcare institution committed to providing world-class medical services with a patient-centric approach. Our experienced team of doctors, nurses, and support staff ensures that you receive the highest standard of care.
            </p>
            <p className="text-lg mb-6 leading-relaxed">
              At Unity Hospital, we combine advanced medical technology with compassionate care to create a healing environment. Our mission is to improve the health and wellbeing of the communities we serve.
            </p>
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary text-3xl mb-2">
                  <i className="fas fa-user-md"></i>
                </div>
                <h3 className="font-heading font-semibold text-lg mb-1">Expert Doctors</h3>
                <p className="text-gray-600">Experienced specialists providing exceptional care</p>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary text-3xl mb-2">
                  <i className="fas fa-procedures"></i>
                </div>
                <h3 className="font-heading font-semibold text-lg mb-1">Modern Facilities</h3>
                <p className="text-gray-600">State-of-the-art equipment and amenities</p>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary text-3xl mb-2">
                  <i className="fas fa-ambulance"></i>
                </div>
                <h3 className="font-heading font-semibold text-lg mb-1">24/7 Emergency</h3>
                <p className="text-gray-600">Round-the-clock emergency medical services</p>
              </div>
              <div className="bg-light p-4 rounded-lg">
                <div className="text-primary text-3xl mb-2">
                  <i className="fas fa-heartbeat"></i>
                </div>
                <h3 className="font-heading font-semibold text-lg mb-1">Patient-Focused</h3>
                <p className="text-gray-600">Compassionate care centered on your needs</p>
              </div>
            </div>
          </div>

          {/* Hospital Image */}
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1538108149393-fbbd81895907?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600&q=80" 
              alt="Unity Hospital Building" 
              className="rounded-lg shadow-lg w-full"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
