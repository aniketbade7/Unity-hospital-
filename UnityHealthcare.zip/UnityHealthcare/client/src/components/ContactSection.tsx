import React from 'react';
import GoogleMap from './GoogleMap';

const ContactSection: React.FC = () => {
  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-heading font-bold mb-4">Get in Touch with Us</h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            We're here to address your queries and provide assistance.
          </p>
          <div className="w-20 h-1 bg-primary mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Contact Information */}
          <div>
            <div className="bg-light p-8 rounded-xl shadow-md mb-8">
              <h3 className="text-2xl font-heading font-bold mb-6">Contact Information</h3>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-map-marker-alt text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-lg">Address</h4>
                    <p className="text-gray-600">Unity Hospital, Pathardi, Maharashtra, India</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-phone text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-lg">Phone</h4>
                    <p className="text-gray-600">Main: <a href="tel:+918698097916" className="text-tertiary">+91 8698 097 916</a></p>
                    <p className="text-gray-600">Emergency: <a href="tel:+918698097916" className="text-emergency font-medium">+91 8698 097 916</a></p>
                    <p className="text-gray-600">Alternate: <a href="tel:+918857052939" className="text-tertiary">+91 8857 052 939</a></p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-primary/10 p-3 rounded-full mr-4">
                    <i className="fas fa-envelope text-primary text-xl"></i>
                  </div>
                  <div>
                    <h4 className="font-heading font-semibold text-lg">Email</h4>
                    <p className="text-gray-600">General Inquiries: <a href="mailto:info@unityhospital.com" className="text-tertiary">info@unityhospital.com</a></p>
                    <p className="text-gray-600">Appointments: <a href="mailto:appointments@unityhospital.com" className="text-tertiary">appointments@unityhospital.com</a></p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h4 className="font-heading font-semibold text-lg mb-4">Connect With Us</h4>
                <div className="flex space-x-4">
                  <a href="#" className="bg-tertiary text-white p-3 rounded-full hover:bg-tertiary/90 transition">
                    <i className="fab fa-facebook-f"></i>
                  </a>
                  <a href="https://www.instagram.com/unity.group_official?utm_source=qr&igsh=YzI4NTUwdWltM2g=" target="_blank" rel="noopener noreferrer" className="bg-tertiary text-white p-3 rounded-full hover:bg-tertiary/90 transition">
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a href="#" className="bg-tertiary text-white p-3 rounded-full hover:bg-tertiary/90 transition">
                    <i className="fab fa-linkedin-in"></i>
                  </a>
                  <a href="#" className="bg-tertiary text-white p-3 rounded-full hover:bg-tertiary/90 transition">
                    <i className="fab fa-twitter"></i>
                  </a>
                </div>
              </div>
            </div>

            {/* Hospital Hours */}
            <div className="bg-secondary/10 p-6 rounded-xl">
              <div className="flex items-center mb-4">
                <i className="far fa-clock text-secondary text-xl mr-3"></i>
                <h4 className="font-heading font-bold text-lg">Hospital Hours</h4>
              </div>
              <ul className="space-y-2">
                <li className="flex justify-between">
                  <span className="text-gray-600">Monday - Friday:</span>
                  <span className="font-medium">8:00 AM - 9:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">Saturday:</span>
                  <span className="font-medium">8:00 AM - 7:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span className="text-gray-600">Sunday:</span>
                  <span className="font-medium">9:00 AM - 5:00 PM</span>
                </li>
                <li className="flex justify-between mt-2 pt-2 border-t border-gray-300">
                  <span className="text-gray-600">Emergency Services:</span>
                  <span className="font-medium text-emergency">24/7</span>
                </li>
              </ul>
            </div>
          </div>

          {/* Google Map */}
          <div className="h-full min-h-[400px] bg-gray-200 rounded-xl overflow-hidden shadow-md">
            <GoogleMap />
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactSection;
