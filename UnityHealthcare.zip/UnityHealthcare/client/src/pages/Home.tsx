import React from 'react';
import HeroSection from '@/components/HeroSection';
import AboutSection from '@/components/AboutSection';
import ServicesSection from '@/components/ServicesSection';
import DoctorsSection from '@/components/DoctorsSection';
import FacilitiesSection from '@/components/FacilitiesSection';
import StatisticsSection from '@/components/StatisticsSection';
import AppointmentSection from '@/components/AppointmentSection';
import TestimonialsSection from '@/components/TestimonialsSection';
import ContactSection from '@/components/ContactSection';
import CTASection from '@/components/CTASection';

const Home: React.FC = () => {
  return (
    <main>
      <HeroSection />
      <AboutSection />
      <ServicesSection />
      <DoctorsSection />
      <FacilitiesSection />
      <StatisticsSection />
      <AppointmentSection />
      <TestimonialsSection />
      <ContactSection />
      <CTASection />
    </main>
  );
};

export default Home;
