// Services Data
export const services = [
  {
    icon: "fas fa-stethoscope",
    title: "General Medicine",
    description: "Comprehensive medical care for adults, including diagnosis and treatment of various diseases and preventive healthcare."
  },
  {
    icon: "fas fa-ambulance",
    title: "24/7 Ambulance Services",
    description: "Immediate emergency response with fully equipped ambulances, trained paramedics and advanced life-support systems available 24/7."
  },
  {
    icon: "fas fa-cut",
    title: "Surgery",
    description: "Expert surgical procedures performed by skilled surgeons using advanced techniques and modern equipment."
  },
  {
    icon: "fas fa-baby",
    title: "Obstetrics and Gynecology",
    description: "Specialized care for women, including pregnancy, childbirth, and treatment of female reproductive system disorders."
  },
  {
    icon: "fas fa-child",
    title: "Pediatrics",
    description: "Comprehensive healthcare for infants, children and adolescents, focusing on growth, development and disease prevention."
  },
  {
    icon: "fas fa-bone",
    title: "Orthopedics",
    description: "Specialized treatment for bones, joints, ligaments, tendons, muscles and nerves, with both surgical and non-surgical options."
  },
  {
    icon: "fas fa-heartbeat",
    title: "Cardiology",
    description: "Comprehensive care for heart-related conditions, including diagnosis, treatment and preventive cardiology services."
  }
];

// Doctors Data
export const doctors = [
  {
    name: "Dr. Ashok Bade",
    specialty: "Head of Department",
    bio: "Leading our medical team with extensive experience and expertise in hospital administration and patient care management.",
    image: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  },
  {
    name: "Dr. Abhijit Pawar",
    specialty: "General Physician",
    bio: "MBBS, MD Medicine. Specializes in internal medicine with a comprehensive approach to diagnosis and treatment.",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  },
  {
    name: "Dr. Ramesh Tonde",
    specialty: "Orthopedic Surgeon",
    bio: "MBBS, DNB Ortho. Experienced orthopedic specialist with expertise in joint replacements and fracture management.",
    image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  },
  {
    name: "Dr. Ashishkumar Chaudhari",
    specialty: "Cardiologist",
    bio: "DM Cardiology. Expert in cardiac care, diagnosis and treatment of various cardiovascular diseases with advanced techniques.",
    image: "https://images.unsplash.com/photo-1628595351029-c2bf17511435?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  },
  {
    name: "Dr. Sandeep Bhabad",
    specialty: "Pediatrician",
    bio: "MBBS, DCH. Dedicated to providing comprehensive healthcare for children from newborns to adolescents.",
    image: "https://images.unsplash.com/photo-1584432810601-6c7f27d2362b?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  },
  {
    name: "Dr. Rajendra Khedkar",
    specialty: "Ayurvedic Physician",
    bio: "BAMS. Specializes in traditional Ayurvedic treatments and holistic healthcare approaches for various ailments.",
    image: "https://images.unsplash.com/photo-1511437104287-da1a1817122f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  },
  {
    name: "Dr. Amol Shirsat",
    specialty: "Ayurvedic Physician",
    bio: "BAMS. Expert in Ayurvedic medicine with focus on natural healing methods and preventive healthcare.",
    image: "https://images.unsplash.com/photo-1542736667-069246bdbc6d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300&q=80"
  }
];

// Facilities Data
export const facilities = [
  {
    title: "Modern Operation Theaters",
    description: "Equipped with advanced surgical equipment and maintained with highest standards of cleanliness.",
    image: "https://images.unsplash.com/photo-1551076805-e1869033e561?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "Fully Equipped ICU",
    description: "24/7 intensive care facilities with continuous monitoring systems and life support equipment.",
    image: "https://images.unsplash.com/photo-1579154204601-01588f351e67?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "Advanced Radiology",
    description: "Comprehensive imaging services including X-ray, Ultrasound, and CT Scan with rapid results.",
    image: "https://images.unsplash.com/photo-1629909613654-28e377c37b09?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "24/7 Ambulance Services",
    description: "Fully equipped ambulances with trained staff available round-the-clock for emergency medical transportation.",
    image: "https://images.unsplash.com/photo-1613574708711-fe28e7ffe2a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "In-house Pharmacy",
    description: "Fully stocked pharmacy providing prescribed medications with expert pharmacist consultation.",
    image: "https://images.unsplash.com/photo-1587854680352-936b22b91030?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "24/7 Emergency Services",
    description: "Round-the-clock emergency care with rapid response teams and critical care capabilities.",
    image: "https://images.unsplash.com/photo-1601841197690-6f0838bdb005?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "Comfortable Patient Rooms",
    description: "Well-appointed patient rooms designed for comfort, recovery and peace of mind.",
    image: "https://images.unsplash.com/photo-1631248055158-edec7a3c072b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  },
  {
    title: "Cardiac Care Unit",
    description: "Specialized cardiac care center with advanced monitoring and treatment facilities for heart patients.",
    image: "https://images.unsplash.com/photo-1581594693702-fbdc51b2763b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
  }
];

// Testimonials Data
export const testimonials = [
  {
    name: "Anita Mehta",
    initials: "AM",
    title: "Orthopedic Patient",
    text: "I cannot express how grateful I am for the care I received at Unity Hospital. The staff was incredibly attentive, and Dr. Sharma's expertise made me feel confident throughout my treatment. Truly exceptional healthcare service!",
    rating: 5,
    halfStar: false
  },
  {
    name: "Sunita Patel",
    initials: "SP",
    title: "Maternity Patient",
    text: "The maternity care at Unity Hospital was outstanding. From prenatal consultations to delivery and postnatal care, every step was handled with professionalism and warmth. Dr. Desai and her team made this experience so much better than I anticipated.",
    rating: 5,
    halfStar: false
  },
  {
    name: "Rahul Joshi",
    initials: "RJ",
    title: "Parent of Pediatric Patient",
    text: "When my son needed emergency care, Unity Hospital's prompt response and professional treatment were impressive. The pediatric team was not only skilled but also compassionate. We felt supported throughout the entire process. Highly recommend!",
    rating: 4,
    halfStar: true
  }
];
